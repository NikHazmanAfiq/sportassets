package com.example.sportassets;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
public class Database extends SQLiteOpenHelper {
    private static final String DATABASE_NAME = "sport_assets.db";
    private static final String TABLE_NAME = "assetsTable";
    private static final String COL1 = "ID";
    private static final String COL2 = "sport_assets";
    private static final String COL3 = "quantity";
    public Database(Context context) {
        super(context, DATABASE_NAME, null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String createTable = "CREATE TABLE " + TABLE_NAME + " (ID INTEGER PRIMARY KEY AUTOINCREMENT, " + " " + COL2 + " TEXT, " + COL3 + " INTEGER)";
        db.execSQL(createTable);
    }
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion)
    {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_NAME);
        onCreate(db);
    }
    public boolean addData(String addAssets, int addQuantity){
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(COL2, addAssets);
        contentValues.put(COL3, addQuantity);
        long result = db.insert(TABLE_NAME, null, contentValues);
        if(result == -1){
            return false;
        } else {
            return true;
        }
    }
    public Cursor getData(){
        SQLiteDatabase db = this.getWritableDatabase();
        String query = "SELECT * FROM " + TABLE_NAME;
        Cursor data = db.rawQuery(query, null);
        return data;
    }
    public Cursor getDataForUpdate(String udAssets){
        SQLiteDatabase db = this.getWritableDatabase();
        String query = "SELECT " + COL1 + " FROM " + TABLE_NAME +
                " WHERE " + COL2 + " = &#39;" + udAssets + "&#39;";
        Cursor data = db.rawQuery(query, null);
        return data;
    }
    public boolean updateData(String udAsset,String udId,int udquantity){
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(COL2, udAsset);
        contentValues.put(COL3, udquantity);
        String whereClause = COL1 + " = ?";
        String[] whereArgs = new String[] { udId };
        int count = db.update(TABLE_NAME, contentValues, whereClause,
                whereArgs);
        if (count > 0) {

            return true;
        } else {
            return false;
        }
    }
    public boolean deleteData(String udAsset){
        SQLiteDatabase db = this.getWritableDatabase();
        String whereClause = COL2 + " = ?";
        String[] whereArgs = new String[] { udAsset };
        int count = db.delete(TABLE_NAME, whereClause, whereArgs);
        if (count > 0) {
            return true;
        } else {
            return false;
        }
    }
}