package com.example.sportassets;
import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import android.widget.EditText;
import android.widget.Toast;
public class AddAssetsActivity extends AppCompatActivity {
    Database mDatabaseHelper;
    EditText assets, assetsQuantity;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_assets);
        assets = findViewById(R.id.assets);
        assetsQuantity = findViewById(R.id.assetsQuantity);
        Button saveNote = findViewById(R.id.btnAddAssets);
        Button cancelSaveNote= findViewById(R.id.btnCancel);
        mDatabaseHelper = new Database(this);
        saveNote.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String addAsset = assets.getText().toString();
                String addQuantity = assetsQuantity.getText().toString();
                if (addAsset.equals("") || addQuantity.equals("")) {
                    toastMessage("Please fill in all the fields.");
                } else {
                    int quantity = Integer.parseInt(addQuantity);
                    boolean InsertData = mDatabaseHelper.addData(addAsset,
                            quantity);
                    if (InsertData) {
                        toastMessage("Data successfully inserted!");
                        Intent intent = new Intent(AddAssetsActivity.this,
                                ListAssetsActivity.class);
                        startActivity(intent);
                    } else {
                        toastMessage("Something went wrong.");
                    }
                }
            }
        });
        cancelSaveNote.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(AddAssetsActivity.this,
                        ListAssetsActivity.class);
                startActivity(intent);
            }
        });
    }
    private void toastMessage(String message) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show();

    }
}