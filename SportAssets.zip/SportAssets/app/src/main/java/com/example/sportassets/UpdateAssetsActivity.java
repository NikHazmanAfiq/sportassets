package com.example.sportassets;
import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
public class UpdateAssetsActivity extends AppCompatActivity {
    private EditText etUpdateAssets;
    private EditText etUpdateQuantity;
    private Button btnUpdate;
    private Button btnDelete;
    private String selectedID;
    private String selectedAsset;
    private int selectedQuantity;
    private Database mDatabaseHelper;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_update_assets);
        etUpdateAssets = findViewById(R.id.etassets);
        etUpdateQuantity = findViewById(R.id.etassetsQuantity);
        btnUpdate = findViewById(R.id.btnUpdate);
        btnDelete = findViewById(R.id.btnDelete);
        mDatabaseHelper = new Database(this);
        Intent receivedIntent = getIntent();
        selectedID = receivedIntent.getStringExtra("id");
        selectedAsset = receivedIntent.getStringExtra("asset");
        selectedQuantity = receivedIntent.getIntExtra("quantity", 0);
        etUpdateAssets.setText(selectedAsset);
        etUpdateQuantity.setText(String.valueOf(selectedQuantity));
        btnUpdate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String asset = etUpdateAssets.getText().toString();
                int quantity =
                        Integer.parseInt(etUpdateQuantity.getText().toString());

                boolean isUpdated = mDatabaseHelper.updateData(asset,
                        selectedID, quantity);
                if (isUpdated) {
                    Toast.makeText(UpdateAssetsActivity.this, "Updated",
                    Toast.LENGTH_SHORT).show();
                    Intent intent = new Intent(UpdateAssetsActivity.this,
                            MainActivity.class);
                    startActivity(intent);
                } else {
                    Toast.makeText(UpdateAssetsActivity.this, "Update failed", Toast.LENGTH_SHORT).show();
                }
            }
        });
        btnDelete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                boolean isDeleted =
                        mDatabaseHelper.deleteData(selectedAsset);
                if (isDeleted) {
                    Toast.makeText(UpdateAssetsActivity.this, "Deleted",
                    Toast.LENGTH_SHORT).show();
                    Intent intent = new Intent(UpdateAssetsActivity.this,
                            MainActivity.class);
                    startActivity(intent);
                } else {
                    Toast.makeText(UpdateAssetsActivity.this, "Delete failed", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
}