package com.example.sportassets;
        import androidx.appcompat.app.AppCompatActivity;
        import android.content.Intent;
        import android.os.Bundle;
        import android.view.View;

        import android.widget.Button;
public class MainActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Button toAddAssets = findViewById(R.id.btnAddAssets);
        Button toListAssets = findViewById(R.id.btnViewList);
//navigate to Add Assets Activity
        toAddAssets.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent addAssetsIntent = new Intent(MainActivity.this,
                        AddAssetsActivity.class);
                startActivity(addAssetsIntent);
            }
        });
//navigate to List Assets Activity
        toListAssets.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent listAssetsIntent = new Intent(MainActivity.this,
                        ListAssetsActivity.class);
                startActivity(listAssetsIntent);
            }
        });
    }
}