package com.example.sportassets;
import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListAdapter;
import android.widget.ListView;
import androidx.appcompat.app.AppCompatActivity;
import java.util.ArrayList;
public class ListAssetsActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_list_assets);
        final ListView lvAssetList = findViewById(R.id.lvAssets);
        final Database mDatabaseHelper = new Database(this);
        final Cursor data = mDatabaseHelper.getData();
        final ArrayList<String> listData = new ArrayList<>();
        while (data.moveToNext()) {
            listData.add(data.getString(0) + " - " + data.getString(1) + " ("
            + data.getString(2) + ")");
        }
        ListAdapter adapter = new ArrayAdapter<>(this,
                android.R.layout.simple_list_item_1, listData);
        lvAssetList.setAdapter(adapter);
        lvAssetList.setOnItemClickListener(new
                                                   AdapterView.OnItemClickListener() {
                                                       @Override
                                                       public void onItemClick(AdapterView<?> parent, View view, int
                                                       position, long id) {
                                                           Cursor selectedItem = (Cursor)
                                                                   parent.getItemAtPosition(position);
                                                           String itemId =
                                                                   selectedItem.getString(selectedItem.getColumnIndexOrThrow("ID"));
                                                           String itemName =
                                                                   selectedItem.getString(selectedItem.getColumnIndexOrThrow("sport_assets"));
                                                           String itemQuantity =
                                                                   selectedItem.getString(selectedItem.getColumnIndexOrThrow("quantity"));
                                                           Intent intent = new Intent(ListAssetsActivity.this,
                                                                   UpdateAssetsActivity.class);
                                                           intent.putExtra("ID", itemId);
                                                           intent.putExtra("sport_assets", itemName);
                                                           intent.putExtra("quantity", itemQuantity);
                                                           startActivity(intent);
                                                       }
                                                   });
    }
}